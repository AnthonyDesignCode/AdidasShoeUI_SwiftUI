//
//  ComplexShoeUI_SwiftUIApp.swift
//  ComplexShoeUI_SwiftUI
//
//  Created by Anthony Codes on 15/09/2020.
//

import SwiftUI

@main
struct ComplexShoeUI_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
