//
//  ContentView.swift
//  ComplexShoeUI_SwiftUI
//
//  Created by Anthony Codes on 15/09/2020.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ShoeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ShoeView: View {
    //View
    var black = Color.black.opacity(0.7)
    var width = UIScreen.main.bounds.width
    var edges = UIApplication.shared.windows.first?.safeAreaInsets
    
    //Data
    @State var more = false
    @State var gender = "Male"
    @State var size = 6
    var sizes = [6,7,9,10,12]
    
    @State var added = false
    
    var body : some View {
        VStack {
            ZStack {
                HStack {
                    Button(action: {}) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 22))
                            .foregroundColor(Color("red"))
                            .frame(width: 40, height: 40)
                            .background(Color("bg"))
                            .cornerRadius(10)
                            .shadow(color: Color.black.opacity(0.2), radius: 5, x: 5, y: 5)
                    }
                    Spacer(minLength: 0)
                    Button(action: {}) {
                        Image(systemName: "suit.heart.fill")
                            .font(.system(size: 22))
                            .foregroundColor(Color("red"))
                            .frame(width: 40, height: 40)
                            .background(Color("bg"))
                            .cornerRadius(10)
                            .shadow(color: Color.black.opacity(0.2), radius: 5, x: 5, y: 5)
                    }
                }
                Image("adidas")
                    .resizable()
                    .frame(width: 55, height: 55)
            }.padding()
            Image("shoe")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: width - (more ? 200 : 100))
                .padding(.top, 25)
            
            //This is for smaller iPhones, FixUI
            ScrollView(UIScreen.main.bounds.height < 750 ? .vertical : .init(), showsIndicators: false) {
                VStack {
                    HStack {
                        Text("SUPERSTAR SHOES")
                            .font(.title2)
                            .fontWeight(.heavy)
                            .foregroundColor(black)
                        Spacer(minLength: 0)
                        Text("£79.95")
                            .font(.title2)
                            .fontWeight(.heavy)
                            .foregroundColor(black)
                    }
                    .padding(.top, 25)
                    .padding(.trailing)
                    
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Since their beginning, the iconic adidas Superstar Shoes have been worn by those paving the way. Those who have stood for themselves and stood for others. That list includes you. In honour of inclusivity, this version features bold colours that represent every colour we can see in this world. The 3-Stripes and rubber shell toe endure.")
                            .lineLimit(more ? nil : 3)
                            .foregroundColor(black)
                        Button(action: {
                                withAnimation {
                                    more.toggle()
                                }}) {
                            Text(more ? "Less" : "Read More")
                                .fontWeight(.bold)
                                .foregroundColor(black)
                        }
                    }.padding([.vertical, .trailing])
                    HStack(spacing: 15) {
                        Text("Gender")
                            .fontWeight(.heavy)
                            .foregroundColor(black)
                            .frame(width: 75, alignment: .leading)
                        GenderButton(gender: $gender, title: "Male")
                        GenderButton(gender: $gender, title: "Female")
                        Spacer(minLength: 0)
                    }
                    .padding(.trailing)
                    .padding(.top, 10)
                    HStack(spacing: 15) {
                        Text("Size")
                            .fontWeight(.heavy)
                            .foregroundColor(black)
                            .frame(width: 75, alignment: .leading)
                        ForEach(sizes, id: \.self) {title in
                            SizeButton(size: $size, title: title)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.trailing)
                    .padding(.top, 10)
                    Spacer(minLength: 0)
                    
                    Button(action: {added.toggle()}) {
                        
                        Label(title: {
                            Text(added ? "Added" : "Add to Bag")
                                .font(.title2)
                                .foregroundColor(.white)
                                .fontWeight(.heavy)
                        }) {
                            
                            Image(systemName: added ? "" : "")
                                .font(.system(size: 22))
                                .foregroundColor(.white)
                        }
                        .padding(.vertical,12)
                        .frame(width: width - 75)
                        .background(added ? Color("red") : black)
                        .clipShape(Capsule())
                        .padding(.leading,-45)
                        .padding(.top)
                        .padding(.bottom,edges!.bottom == 0 ? 15 : edges!.bottom)
                    }
                }
                .padding(.leading, 45)
            }
            .background(Color.white)
            .shadow(radius: 0)
            .clipShape(CustomShape())
            .padding(.top, 30)
            .shadow(color: Color.black.opacity(0.12), radius: 5, x: -5, y: -10)
        }
        .background(Color("bg").ignoresSafeArea(.all, edges: .all))
        .ignoresSafeArea(.all, edges: .bottom)
    }
}

struct GenderButton: View {
    
    @Binding var gender : String
    var title : String
    var black = Color.black.opacity(0.7)
    
    var body : some View {
        Button(action: {gender = title}) {
            Text(title)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(gender == title ? .white : black)
                .padding(.vertical, 10)
                .frame(width: 80)
                .background(gender == title ? Color("red") : Color.white)
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.2), radius: 5, x: 5, y: 5)
        }
    }
}

struct SizeButton : View {
    
    @Binding var size : Int
    var title : Int
    var black = Color.black.opacity(0.7)
    
    var body: some View{
        
        Button(action: {size = title}) {
            
            Text("\(title)")
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(size == title ? .white : black)
                .frame(width: 35,height: 35)
                .background(size == title ? Color("red") : Color.white)
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.2), radius: 5, x: 5, y: 5)
        }
    }
}

struct CustomShape : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.topLeft], cornerRadii: CGSize(width: 85, height: 85))
        
        return Path(path.cgPath)
    }
}
